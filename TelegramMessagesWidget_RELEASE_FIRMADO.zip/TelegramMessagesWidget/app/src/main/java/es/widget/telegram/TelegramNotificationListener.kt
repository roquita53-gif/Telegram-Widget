package es.widget.telegram

import android.app.Notification
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class TelegramNotificationListener : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        // Sincroniza el widget con las notificaciones que siguen activas al conectar el servicio.
        syncActiveTelegramNotifications()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != TELEGRAM_PACKAGE) return
        val message = extractMessage(sbn) ?: return
        MessageStore.put(
            this,
            sbn.key,
            message.first,
            message.second,
            sbn.postTime
        )
        refreshWidget()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.packageName != TELEGRAM_PACKAGE) return
        // Cuando Android retira la notificación (por lectura, descarte o limpieza),
        // deja de mostrarse en el widget.
        MessageStore.remove(this, sbn.key)
        refreshWidget()
    }

    private fun syncActiveTelegramNotifications() {
        val active = try {
            activeNotifications.orEmpty()
        } catch (_: Exception) {
            emptyArray()
        }
        val current = active
            .filter { it.packageName == TELEGRAM_PACKAGE }
            .mapNotNull { sbn ->
                val message = extractMessage(sbn) ?: return@mapNotNull null
                ChatMessage(sbn.key, message.first, message.second, sbn.postTime)
            }
        MessageStore.replaceAll(this, current)
        refreshWidget()
    }

    private fun extractMessage(sbn: StatusBarNotification): Pair<String, String>? {
        val extras: Bundle = sbn.notification.extras ?: return null
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() || text.isBlank()) return null
        return title to text
    }

    private fun refreshWidget() {
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(
            ComponentName(this, TelegramWidgetProvider::class.java)
        )
        if (ids.isNotEmpty()) {
            manager.notifyAppWidgetViewDataChanged(ids, R.id.widget_list)
        }
    }

    companion object {
        private const val TELEGRAM_PACKAGE = "org.telegram.messenger"
    }
}
