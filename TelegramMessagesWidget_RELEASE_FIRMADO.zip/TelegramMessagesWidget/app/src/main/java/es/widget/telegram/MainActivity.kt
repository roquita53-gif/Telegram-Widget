package es.widget.telegram

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            setBackgroundColor(0xFFF4F8FC.toInt())
        }
        layout.addView(TextView(this).apply {
            text = "Mensajes Telegram"
            textSize = 24f
            setTextColor(0xFF168ACB.toInt())
        })
        layout.addView(TextView(this).apply {
            text = "Para mostrar varios mensajes recibidos en el widget, Android necesita permiso para leer las notificaciones de Telegram. Los mensajes se guardan únicamente en este teléfono. No se solicita tu contraseña ni se conecta a tu cuenta."
            textSize = 16f
            setTextColor(0xFF263746.toInt())
            setPadding(0, 24, 0, 24)
        })
        layout.addView(Button(this).apply {
            text = "Activar acceso a notificaciones"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "Abrir Telegram"
            setOnClickListener { packageManager.getLaunchIntentForPackage("org.telegram.messenger")?.let { startActivity(it) } }
        })
        setContentView(layout)
    }
}
