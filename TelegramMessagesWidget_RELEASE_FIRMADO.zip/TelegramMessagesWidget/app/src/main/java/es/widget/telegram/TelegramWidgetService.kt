package es.widget.telegram

import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import android.widget.RemoteViewsService

class TelegramWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory =
        MessageViewsFactory(applicationContext)
}

private class MessageViewsFactory(
    private val context: Context
) : RemoteViewsService.RemoteViewsFactory {

    private var items: List<ChatMessage> = emptyList()

    override fun onCreate() = Unit

    override fun onDataSetChanged() {
        items = MessageStore.get(context)
    }

    override fun onDestroy() {
        items = emptyList()
    }

    override fun getCount(): Int = items.size

    override fun getViewAt(position: Int): RemoteViews? {
        if (position !in items.indices) return null

        val item = items[position]
        val clickIntent = Intent().setAction("OPEN_TELEGRAM")

        return RemoteViews(context.packageName, R.layout.widget_message_row).apply {
            setTextViewText(R.id.sender, item.sender)
            setTextViewText(R.id.message, item.body)
            setTextViewText(R.id.time, MessageStore.timeLabel(item.time))
            setTextViewText(
                R.id.avatar,
                item.sender.trim().firstOrNull()?.uppercase() ?: "T"
            )

            setOnClickFillInIntent(R.id.avatar, Intent(clickIntent))
            setOnClickFillInIntent(R.id.sender, Intent(clickIntent))
            setOnClickFillInIntent(R.id.message, Intent(clickIntent))
            setOnClickFillInIntent(R.id.time, Intent(clickIntent))
        }
    }

    override fun getLoadingView(): RemoteViews? = null
    override fun getViewTypeCount(): Int = 1

    override fun getItemId(position: Int): Long =
        items.getOrNull(position)?.let {
            it.time xor it.sender.hashCode().toLong()
        } ?: position.toLong()

    override fun hasStableIds(): Boolean = true
}
