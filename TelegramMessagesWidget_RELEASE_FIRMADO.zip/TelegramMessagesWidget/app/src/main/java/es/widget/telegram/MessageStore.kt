package es.widget.telegram

import android.content.Context
import android.util.Base64
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

 data class ChatMessage(val sender: String, val body: String, val time: Long)

object MessageStore {
    private const val PREFS = "telegram_messages"
    private const val KEY = "items"
    private fun enc(s: String) = Base64.encodeToString(s.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
    private fun dec(s: String) = try { String(Base64.decode(s, Base64.NO_WRAP), Charsets.UTF_8) } catch (_: Exception) { "" }

    @Synchronized fun add(context: Context, sender: String, body: String, time: Long) {
        if (body.isBlank()) return
        val all = get(context).toMutableList()
        all.add(0, ChatMessage(sender.ifBlank { "Telegram" }, body, time))
        val unique = all.distinctBy { "${it.sender}|${it.body}|${it.time / 60000}" }.take(40)
        val encoded = unique.joinToString("\n") { "${it.time}|${enc(it.sender)}|${enc(it.body)}" }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, encoded).apply()
    }

    fun get(context: Context): List<ChatMessage> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
        return raw.lines().mapNotNull { line ->
            val p = line.split('|', limit = 3)
            if (p.size != 3) null else try { ChatMessage(dec(p[1]), dec(p[2]), p[0].toLong()) } catch (_: Exception) { null }
        }.sortedByDescending { it.time }
    }

    fun timeLabel(time: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))
}
