package es.widget.telegram

import android.content.Context
import android.util.Base64
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ChatMessage(
    val notificationKey: String,
    val sender: String,
    val body: String,
    val time: Long
)

object MessageStore {
    private const val PREFS = "telegram_messages"
    private const val KEY = "active_notifications"

    private fun enc(value: String): String =
        Base64.encodeToString(value.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)

    private fun dec(value: String): String = try {
        String(Base64.decode(value, Base64.NO_WRAP), Charsets.UTF_8)
    } catch (_: Exception) {
        ""
    }

    @Synchronized
    fun put(context: Context, key: String, sender: String, body: String, time: Long) {
        if (body.isBlank()) return
        val current = get(context).associateBy { it.notificationKey }.toMutableMap()
        current[key] = ChatMessage(
            notificationKey = key,
            sender = sender.ifBlank { "Telegram" },
            body = body,
            time = time
        )
        save(context, current.values.sortedByDescending { it.time }.take(40))
    }

    @Synchronized
    fun remove(context: Context, key: String) {
        val remaining = get(context).filterNot { it.notificationKey == key }
        save(context, remaining)
    }

    @Synchronized
    fun replaceAll(context: Context, messages: List<ChatMessage>) {
        save(context, messages.sortedByDescending { it.time }.take(40))
    }

    private fun save(context: Context, messages: List<ChatMessage>) {
        val raw = messages.joinToString("\n") {
            listOf(
                enc(it.notificationKey),
                it.time.toString(),
                enc(it.sender),
                enc(it.body)
            ).joinToString("|")
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, raw).apply()
    }

    fun get(context: Context): List<ChatMessage> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "") ?: ""
        return raw.lineSequence().mapNotNull { line ->
            val parts = line.split('|', limit = 4)
            if (parts.size != 4) return@mapNotNull null
            try {
                ChatMessage(
                    notificationKey = dec(parts[0]),
                    time = parts[1].toLong(),
                    sender = dec(parts[2]),
                    body = dec(parts[3])
                )
            } catch (_: Exception) {
                null
            }
        }.sortedByDescending { it.time }.toList()
    }

    fun timeLabel(time: Long): String =
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))
}
