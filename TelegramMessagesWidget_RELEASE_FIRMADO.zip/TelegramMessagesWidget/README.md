# Mensajes Telegram — versión revisada del proyecto

## Cambios de esta revisión
- Se conserva el filtro estricto para aceptar únicamente notificaciones de `org.telegram.messenger` (Telegram oficial).
- Se mantiene el servicio `NotificationListenerService`, necesario para leer las notificaciones que alimentan el widget.
- Se desactiva el tráfico HTTP sin cifrar (`usesCleartextTraffic=false`).
- Se mantiene desactivada la copia de seguridad automática (`allowBackup=false`).
- No se añaden permisos de Internet, contactos, SMS, ubicación ni almacenamiento.

## Privacidad y limitaciones
Android exige que el usuario conceda manualmente el acceso de lector de notificaciones. Ese acceso puede permitir a la aplicación leer otras notificaciones del dispositivo; el código de esta app procesa únicamente las de `org.telegram.messenger`.
Los mensajes se guardan localmente en preferencias de la aplicación. El contenido se codifica en Base64, pero **Base64 no es cifrado**; no debe considerarse almacenamiento cifrado.

## Compilación
Este ZIP contiene el código fuente. No contiene un APK ya compilado ni una firma de distribución.
Para compilar, utiliza el flujo `build.yml` del repositorio GitHub que descomprime este proyecto y ejecuta `:app:assembleDebug`.
El resultado será un APK de depuración (`debuggable`), firmado con certificado de depuración. No se garantiza que Google Play Protect permita instalarlo; no se debe desactivar Play Protect ni eludir sus avisos.

## Requisitos
- Android Gradle Plugin 8.7.3
- Kotlin Android plugin 2.0.21
- Java 17
- Compile SDK 35; min SDK 26; target SDK 35
