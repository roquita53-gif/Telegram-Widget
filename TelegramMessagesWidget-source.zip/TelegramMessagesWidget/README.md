# Mensajes Telegram — proyecto Android inicial

Proyecto Kotlin/Android Studio para un widget de inicio con lista vertical de notificaciones recientes de Telegram.

## Qué hace esta versión
- Recoge notificaciones nuevas de la app oficial de Telegram (`org.telegram.messenger`).
- Conserva localmente hasta 40 mensajes recibidos y muestra una lista desplazable en un widget Android.
- Muestra remitente, texto y hora.
- Al tocar el contenido, abre Telegram.

## Limitaciones importantes
- No es todavía un APK compilado ni una aplicación lista para instalar. Este entorno no dispone de Android SDK/Gradle para compilar y firmar el APK.
- Android solo entrega al servicio el contenido que Telegram incluya en sus notificaciones. Si las previsualizaciones están ocultas, el texto puede no estar disponible.
- No recupera mensajes anteriores a la activación del permiso, ni mensajes que Telegram no publique en notificaciones.
- La primera versión abre Telegram al tocar un elemento; no identifica de forma fiable el chat exacto porque Telegram no expone ese dato de manera uniforme en todas las notificaciones.
- El permiso de acceso a notificaciones es sensible: permite a Android entregar a esta app el contenido de las notificaciones. El código filtra Telegram y guarda los textos localmente en SharedPreferences, sin servidor ni transmisión de datos.

## Compilar
1. Abrir esta carpeta con Android Studio reciente.
2. Dejar que Gradle sincronice y descargue Android Gradle Plugin/Kotlin.
3. Compilar con **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Instalar el APK en el Samsung.
5. Abrir **Mensajes Telegram** y pulsar **Activar acceso a notificaciones**.
6. En Ajustes de Android, activar el acceso para **Mensajes Telegram**.
7. Mantener pulsada la pantalla de inicio > Widgets > Mensajes Telegram y añadir el widget.
8. Comprobar que Telegram permite mostrar el contenido de las notificaciones.

## Requisitos
- Android 8.0 o posterior (minSdk 26).
- Android Studio con JDK 17 y SDK Android 35.
