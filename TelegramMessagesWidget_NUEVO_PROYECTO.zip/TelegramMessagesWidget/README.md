# Mensajes Telegram — proyecto Android

Proyecto fuente para compilar el widget de mensajes de la aplicación oficial Telegram (`org.telegram.messenger`).

## Compilación desde GitHub

1. Sube el contenido de esta carpeta al repositorio GitHub, en la raíz de la rama `main`.
2. Abre la pestaña **Actions**.
3. Selecciona **Crear APK Telegram Widget**.
4. Pulsa **Run workflow** si no se inicia automáticamente al subir los cambios.
5. Cuando la ejecución termine en verde (**Success**), abre esa ejecución.
6. En **Artifacts**, descarga `Telegram-Widget-APK.zip`.
7. Descomprime el ZIP descargado: dentro estará `app-debug.apk`.

El flujo usa Java 17 y Gradle 8.9 y publica el APK como artefacto de GitHub Actions.

## Seguridad y privacidad

- La app filtra las notificaciones para aceptar únicamente `org.telegram.messenger`.
- Android requiere que el usuario active manualmente el acceso de lector de notificaciones.
- Ese acceso puede exponer el contenido de notificaciones a la aplicación; los mensajes recibidos se guardan localmente en SharedPreferences.
- No se debe desactivar Google Play Protect ni forzar una instalación si el sistema bloquea el APK. Un APK de depuración no equivale a una aplicación auditada o publicada en Play Store.

## Requisitos

- Android 8.0 o posterior (minSdk 26).
- SDK de compilación 35.
- Java 17 y Android Gradle Plugin 8.7.3.
